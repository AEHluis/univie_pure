10.15.524
=====
- new settings " Enable linking to FIS portal "

10.13.524
=====
- fixed API calls and caching

10.12.524
=====
- Added filter for "inPress" for publications (research outputs)

10.11.524
=====
- added bibtex support

10.10.524
=====
- CURL Caching reload from source if cache is empty

10.9.524
=====
- CURL Caching 24h implemented

10.8.524
=====
- CURL Timeout added

10.7.521
=====
- wizardItems.plugin added 
- icon improved

10.6.521
=====
- sql injection filter for filter args

10.5.521
=====
- old OrgUnits are loaded in BE


....

4.6.516 
===== 
- Langformat für Dissertationen inkl. Betreuerangabe als Zitationsstil,   
  basierend aus "portalDetails" und "portal-short" 
- Der Cache beim Laden der Personen und Einrichtungsliste im Bckend wieder aktiviert. (ca. 3h) 
- H1 H2 H3 H4 Reihenfolge von Publikationen in Listendarstellung korrigiert 
- CSS Styling optimiert	

4.5.516
=====
- added Supervisor  in detail research output view
- renamed author to authored by and supervisor to supervised by
- Bugfix: Searchbar does forget searchterm while using pagination
- Bugfix: if an enclosing accordion with a fis-plgin and active pagination is used, the View is nasty destroyed

4.4.516
=====
- translation fallback if abstract or ext org unit is empty
- Show any kind of electronic version of researchoutput in details view including status (open/closed)

4.3.516
=====
- research object can have multiple staus
- order by publication date now added  

4.2.516
=====
- localisation of research output details page

4.1.516
=====
- deactivated PersonCache, no need for it at the moment

4.0.516
=====
- initial productive release